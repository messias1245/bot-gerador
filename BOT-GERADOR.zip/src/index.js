const { Client, Collection, MessageEmbed } = require("discord.js");
const moment = require("moment");
const { load, loadData, findGen, getLimit, addLimit, clear, save, captcha, formatTime, genKey } = require("./funcs");

const app = new Client({ intents: 9983 });
const [timers, keys] = loadData();

app.on("messageCreate", async (msg) => {
  if (msg.type !== "DEFAULT" || msg.author.bot || !msg.guild || !msg.content.startsWith(cfg.PREFIX)) return;

  const args = msg.content.substring(cfg.PREFIX.length).split(/\s+/g);
  const cmd = args.shift().toLowerCase();

  doCmd(msg, args, cmd);
});

async function doCmd(msg, args, cmd) {
  let gen;
  if (cmd.startsWith("gerar")) {
    if ((gen = findGen(cmd.substring(3))) == null) return;
    if (!gen.data.length)
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Estoque esgotado!")
            .setDescription(`Acabou o estoque de ${gen.name} :/`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    if (msg.author.partial) await msg.author.fetch();
    const limit = gen.findLimit(msg.member.roles.cache.map((role) => role.id)),
      data = getLimit(msg.author.id, gen, timers);
    if (limit == -1)
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Parece que você não pode gerar conta de ${gen.name} :/`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    if (data[0] >= limit)
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Limite excedido")
            .setDescription(`O limite diario foi excedido, aguarde ${formatTime(data[1] - Date.now())} para receber sua proxima carga`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    return await msg.author
      .createDM(true)
      .then(async (ch) => {
        const account = gen.select();
        addLimit(msg.author.id, gen, timers);
        msg.reply({
          embeds: [
            new MessageEmbed()
              .setTitle(`Conta gerada com sucesso!`)
              .setDescription(`${msg.author}, você acabou de gerar uma conta da **${gen.name}**, lhe enviamos pela DM.`)
              .setColor("BLACK")
              .setFooter(`Contas • ${msg.client.user.username}`)
              .setTimestamp(),
          ],
        });
        await ch.send({
          embeds: [
            new MessageEmbed()
              .setTitle(`Conta gerada com sucesso`)
              .addField("Tipo de Conta", gen.name)
              .addField("Conta", `\`\`\`${account}\`\`\``)
              .setDescription(`Sua conta foi gerada com sucesso!`)
              .setThumbnail(msg.guild.iconURL({ dynamic: true }))
              .setColor("BLACK")
              .setFooter(`Contas • ${msg.client.user.username}`)
              .setTimestamp(),
          ],
        });
      })
      .catch(
        async (_) =>
          console.log(_) &&
          (await msg.reply({
            embeds: [new MessageEmbed().setTitle(`Calma, um momento.`).setDescription(`${msg.author}, você precisa liberar a DM para poder enviar a mensagem.`)],
          }))
      );
  } else if (cmd.startsWith("produtos")) {
    if (cmd === "produtos") {
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle(`Estoques de Contas`)
            .addFields(cfg.GENERATORS.map((e) => ({ name: e.name, value: `${e.data.length}`, inline: true })))
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    }
    if ((gen = findGen(cmd.substring(5))) == null) return;
    return await msg.reply({
      embeds: [
        new MessageEmbed()
          .setTitle(`Estoque ${gen.data.length ? "disponivel" : "indisponivel"}`)
          .setDescription(`Temos ${gen.data.length} de contas disponiveis para ${gen.name}`)
          .setColor(gen.data.length ? "BLACK" : "RED")
          .setFooter(`Contas • ${msg.client.user.username}`)
          .setTimestamp(),
      ],
    });
  } else if (cmd === "ativarkey" || cmd === "ativarchave") {
    if (!args.length)
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Use \`\`\`${cfg.PREFIX}ativarchave <chave>\`\`\``)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    else if (!keys.has(args[0]))
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Parece que a chave que você está tentando ativar não existe.`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });

    const roleId = keys.get(args[0]);
    const role = await msg.guild.roles.fetch(roleId).catch((e) => null);

    if (!role)
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Você encontrou uma chave com defeito.\n Contate um dos nossos staffs para solucionar o problema.`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });

    return await msg.member.roles
      .add(role)
      .then(async (e) => {
        keys.delete(args[0]);

        save(keys, "keys.json");

        await msg.reply({
          embeds: [
            new MessageEmbed()
              .setDescription(`Você acabou de ativar a chave para ${role}, aproveite!`)
              .setColor("BLACK")
              .setFooter(`Contas • ${msg.client.user.username}`)
              .setTimestamp(),
          ],
        });
      })
      .catch(
        async (e) =>
          await msg.reply({
            embeds: [
              new MessageEmbed()
                .setTitle("Opa, um momento!")
                .setDescription(`Você encontrou uma chave com defeito.\n Contate um dos nossos staffs para solucionar o problema.`)
                .setColor("BLACK")
                .setFooter(`Contas • ${msg.client.user.username}`)
                .setTimestamp(),
            ],
          })
      );
  } else if (cmd === "gerarkey") {
    if (!msg.member.roles.cache.has(cfg.ADMIN_ROLE))
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Você não pode utilizar esse comando.`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    else if (!msg.mentions.roles.first())
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Use \`\`\`${cfg.PREFIX}gerarkey @<cargo>\`\`\``)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });
    else if (msg.mentions.roles.first().rawPosition > msg.guild.me.roles.cache.sort((a, b) => (a > b ? -1 : a < b ? 1 : 0)).first().rawPosition)
      return await msg.reply({
        embeds: [
          new MessageEmbed()
            .setTitle("Opa, um momento!")
            .setDescription(`Esse cargo é superior ao do BOT.`)
            .setColor("BLACK")
            .setFooter(`Contas • ${msg.client.user.username}`)
            .setTimestamp(),
        ],
      });

    return await msg.author
      .createDM(true)
      .then(async (ch) => {
        const key = genKey();
        keys.set(key, msg.mentions.roles.first().id);
        save(keys, "keys.json");

        ch.send({
          embeds: [
            new MessageEmbed()
              .setTitle("Chave criada!")
              .setDescription(`Você acabou de gerar uma chave do cargo ${msg.mentions.roles.first().name}`)
              .addField("Chave", key)
              .setThumbnail(msg.guild.iconURL({ dynamic: true }))
              .setColor("BLACK")
              .setFooter(`Contas • ${msg.client.user.username}`)
              .setTimestamp(),
          ],
        });
        return await msg.reply({
          embeds: [
            new MessageEmbed()
              .setTitle(`Chave gerada com sucesso.`)
              .setDescription(`Olhe a DM para ver a chave.`)
              .setColor("BLACK")
              .setFooter(`Contas • ${msg.client.user.username}`)
              .setTimestamp(),
          ],
        });
      })
      .catch(
        async (_) =>
          await msg.reply({ embeds: [new MessageEmbed().setTitle(`Calma, um momento.`).setDescription(`${msg.author}, você precisa liberar a DM para poder enviar a mensagem.`)] })
      );
  }
}

setInterval(clear, 1000 * 60 * 60, timers);
load();
app.login(cfg.DISCORD_TOKEN);
