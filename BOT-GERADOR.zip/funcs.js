const { readFileSync, writeFileSync, existsSync } = require("fs");
const { resolve } = require("path");
const moment = require("moment");

const CHARS = "ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghjklmnopqrstuvwxyz0123456789";

function load() {
  global.cfg = JSON.parse(readFileSync("./config.json"));
  process.env.DISCORD_TOKEN = cfg.DISCORD_TOKEN;
  cfg.GENERATORS = cfg.GENERATORS.map((name) => gen(name));
}
function loadData() {
  return [
    existsSync("data.json") ? new Map(Object.entries(JSON.parse(readFileSync("data.json", "utf8")))) : new Map(),
    existsSync("keys.json") ? new Map(Object.entries(JSON.parse(readFileSync("keys.json", "utf8")))) : new Map(),
  ];
}
function gen(name) {
  const content = {};
  content.name = name;
  content.id = name.toLowerCase().replace(/[^A-Za-z]/, "");
  if (existsSync(`./contas/${content.id}.txt`)) {
    content.data = readFileSync(`./contas/${content.id}.txt`, { encoding: "utf-8" }).split(/\r\n|\n\r|\n|\r/);
    console.info(`Contas ${content.name} carregadas com sucesso. Total: ${content.data.length}`);
  } else {
    content.data = [];
    console.warn(`Não foi possível encontrar ${resolve(`./contas/${content.id}.txt`)}`);
  }
  content.limits = {};

  for (let [role, limits] of Object.entries(cfg.LIMITS)) {
    if (limits[content.id]) content.limits[role] = limits[content.id];
  }

  console.log(content.id, content.limits);

  content.select = (random = cfg.RANDOM) => {
    if (content.data.length == 0) return null;
    const item = random ? content.data.shift() : content.data.splice(Math.round(Math.random() * content.data.length), 1)[0];
    writeFileSync(`./contas/${content.id}.txt`, content.data.join("\n"));
    return item;
  };

  content.findLimit = (roles) => (roles.length ? roles.map((roleId) => content.limits[roleId] || -1).sort((a, b) => (a > b ? -1 : a < b ? 1 : 0))[0] : -1);

  return content;
}
function findGen(name) {
  for (let gen of cfg.GENERATORS) if (gen.id == name) return gen;
}
function getLimit(id, gen, collection) {
  let data = collection.get(`${id}@${gen.id}`);
  if (!data) return 0;
  data = data.filter((e) => e > Date.now());

  return [data.length, data.sort((a, b) => (a > b ? 1 : a < b ? -1 : 0))[0]];
}
function addLimit(id, gen, collection) {
  const data = collection.get(`${id}@${gen.id}`), date = Date.now() + 24 * 60 * 60 * 1000;
  if (!data) collection.set(`${id}@${gen.id}`, [date]);
  else data.push(date);
  console.log(new Date(date));
  save(collection, "data.json");
}
function save(collection, file) {
  writeFileSync(file, JSON.stringify(Object.fromEntries(collection)), "utf-8");
}
function clear(collection) {
  let count = 0;
  collection.forEach((item) => {
    for (var i = 0, l = item.length; i < l; i++) {
      if (item[i] <= Date.now()) {
        item.splice(i, 1);
        count++;
      }
    }
    if (!item.length) collection.delete(item);
  });
  if (count) save(collection, "data.json");
}

function genKey(n = 25) {
  let text = "";
  for (var i = 0; i < n + 1; i++) text += CHARS.charAt(Math.floor(Math.random() * CHARS.length));
  return text;
}

function formatTime(time) {
  time /= 1000;
  const s = Math.floor(time % 60), m = Math.floor((time / 60) % 60), h = Math.floor((time / 60 / 60));
  return `${h}hr(s), ${m}m e ${s}s`;
}

module.exports = {
  load,
  loadData,
  findGen,
  getLimit,
  addLimit,
  clear,
  save,
  formatTime,
  genKey,
};